/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logicaCliente;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.WARNING_MESSAGE;
import logicaServidor.Servidor;
        

/**
 *
 * @author sala de software
 */
public class Cliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            // TODO code application logic here
            Socket s =new Socket (Servidor.servidor, Servidor.puerto);
            //Scanner teclado= new Scanner (System.in);
             DataOutputStream salida=new DataOutputStream(s.getOutputStream());
            DataInputStream entrada=new  DataInputStream(s.getInputStream());
            Double nota;
          System.out.println("digitando notas \n");
           nota= Double.parseDouble(JOptionPane.showInputDialog("digite un numero")); 
   
           salida.writeDouble(nota);
           System.out.println(" "+entrada.readUTF());//mensaje recibido del servidor
            nota= Double.parseDouble(JOptionPane.showInputDialog("digite un numero")); 
   
           salida.writeDouble(nota);
           System.out.println(" "+entrada.readUTF());//mensaje recibido del servidor
           
           nota= Double.parseDouble(JOptionPane.showInputDialog("digite un numero")); 
   
           salida.writeDouble(nota);
           System.out.println(" "+entrada.readUTF());//mensaje recibido del servidor
           System.out.println(" "+entrada.readUTF());//mensaje recibido del servidor
           s.close();
            
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    
    }
    
}
