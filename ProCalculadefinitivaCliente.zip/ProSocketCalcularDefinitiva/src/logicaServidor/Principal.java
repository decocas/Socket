/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logicaServidor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
 
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author SALA REDES
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try { 
        ServerSocket s=new ServerSocket (Servidor.puerto);
         System.out.println("conectado");
        Socket c=s.accept();
             DataInputStream entrada=new DataInputStream(c.getInputStream());
          DataOutputStream salida=new DataOutputStream(c.getOutputStream()); 
   System.out.println("esperando por el cliente...."+"\n"+"escriba un numero");
          double nota1;
          double nota2;
          double nota3;
          nota1=entrada.readDouble();
          System.out.println("numero digitaddo"+nota1);
          salida.writeUTF("numero recibido fue"+" "+nota1);//mensaje enviado hacia cliente
          nota2=entrada.readDouble();
          System.out.println("numero digitaddo"+nota2);
          salida.writeUTF("numero recibido fue"+" "+nota2);//mensaje enviado hacia cliente
          nota3=entrada.readDouble();
          System.out.println("numero digitaddo"+nota3);
          salida.writeUTF("numero recibido fue"+" "+nota3);//mensaje enviado hacia cliente
          double resultado=Servidor.calcularNota(nota1, nota2, nota3);
          salida.writeUTF("definitiva es"+" "+resultado);//mensaje enviado hacia cliente
        salida.flush();
        c.close();
        
        } catch (IOException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
              
        
    }
    
}
