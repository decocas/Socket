/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logicaServidor;

 

/**
 *
 * @author SALA REDES
 */
public class Servidor {
  public static final int puerto =8888; 
  public static final String servidor="localhost"; 
  
 
public static double calcularNota(double a, double b, double c){

double resultado;
resultado=(0.3*a)+(0.3*b)+(0.4*c);
return resultado ;


}

   


}
